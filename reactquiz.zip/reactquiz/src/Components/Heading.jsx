import React from 'react'


export default function Heading() {
  return (
<div className="main-div-heading-color-change" >
            <h2 className="main-div-h2">Quiz app</h2>   
           
            
            
        </div>
  )
}
